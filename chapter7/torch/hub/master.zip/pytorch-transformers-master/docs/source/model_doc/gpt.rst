OpenAI GPT
----------------------------------------------------

``OpenAIGPTConfig``
~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: pytorch_transformers.OpenAIGPTConfig
    :members:


``OpenAIGPTTokenizer``
~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: pytorch_transformers.OpenAIGPTTokenizer
    :members:


``OpenAIGPTModel``
~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: pytorch_transformers.OpenAIGPTModel
    :members:


``OpenAIGPTLMHeadModel``
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: pytorch_transformers.OpenAIGPTLMHeadModel
    :members:


``OpenAIGPTDoubleHeadsModel``
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: pytorch_transformers.OpenAIGPTDoubleHeadsModel
    :members:
